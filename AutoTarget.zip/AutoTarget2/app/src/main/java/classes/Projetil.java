package classes;

public class Projetil extends Thread{
    int posicao;
    int direcao;
    int velocidade;
}
