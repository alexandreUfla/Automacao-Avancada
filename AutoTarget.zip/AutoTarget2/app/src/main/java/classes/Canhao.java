package classes;

public class Canhao extends Thread{
    int posicao;
    int angulo;

}
